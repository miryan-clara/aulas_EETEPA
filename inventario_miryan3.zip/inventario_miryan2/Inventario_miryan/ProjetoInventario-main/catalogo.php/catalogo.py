print("="*5, "catalogos", "="*5)
print("Loja de Roupas")

catalogo = []

catalogo.append ({
    
    "nome": "vestido florido/rosa",
    "preco": "35.0",
    "estoque": 10
    
    })
catalogo.append ({
    "nome": "vestido florido/azul",
    "preco": "35.0",
    "estoque": 10
    
    })
catalogo.append ({
    
    "nome": "vestido florido/amarelo",
    "preco": "35.0",
    "estoque": 10
    
    })
catalogo.append ({
    
    "nome": "short jeans/aviva",
    "preco": "80.0",
    "estoque": 15
    
    })
catalogo.append ({
    
    "nome": "short jeans/aviva, black",
    "preco": "80.0",
    "estoque": 15
    
    })
catalogo.append ({
    
    "nome": "blusa lilá/aviva",
    "preco": "25.0",
    "estoque": 15
    
    })
catalogo.append ({
    
    "nome": "blusa off white/aviva",
    "preco": "25.0",
    "estoque": 15
    
    })
catalogo.append ({
    
    "nome": "blusa ciano/aviva",
    "preco": "28.0",
    "estoque": 10
    
    })
catalogo.append ({
    
    "nome": "calça legging/ black",
    "preco": "55.0",
    "estoque": 15
    
    })
catalogo.append ({
    
    "nome": "calça legging/ azul marinho",
    "preco": "55.0",
    "estoque": 15
    
    })
catalogo.append ({
    
    "nome": "calça legging/ listrada",
    "preco": "60.0",
    "estoque": 15
    
    })
for i in catalogo:
    print (i)