<?php
$catalogo = [
    [
    "nome"=> "vestido florido/rosa",
    "preco"=> "80.0",
    "estoque"=> 10    
    ],
    [ 
    "nome"=> "vestido florido/azul",
    "preco"=> "80.0",
    "estoque"=> 10
    ],
     [ 
    "nome"=> "vestido florido/amarelo",
    "preco"=> "80.0",
    "estoque"=> 10
    ],
     [ 
    "nome"=> "blusa verde",
    "preco"=> "35.0",
    "estoque"=> 10
    ],
     [ 
    "nome"=> "blusa azul marinho",
    "preco"=> "35.0",
    "estoque"=> 10
    ]
];

foreach ($catalogo as $roupas){
    echo "Roupa: {$roupas['nome']}\n";
    echo "Preço : {$roupas['preco']}\n";



<!DOCTYPE html>
<html lang=pt-br>
<head> 
    <meta charset="UTF8">
    <meta name="viewport" charset="width=device-width, initial-scale=1.0">
    <title>Catálogo de Cursos</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<h1> Catálogo de Cursos</h1>


<div class="catalogo">
   <?php foreach ($catalogo as $item): ?>
       <div class="card">
           <img src="<?= $item['imagem'] ?>">
           <h2><?= $item['nome'] ?></h2>
           <p><?= $item['descricao'] ?></p>
           <span><?= $item['preco'] ?></span>
       </div>
   <?php endforeach; ?>
</div>

</body>
</html>