<?php
$conn = new mysql ("127.0.0.1", "root", "", "tarde_miryan");

if ($conn=>connect_error) {
    die9("Erro de conexão");
}

?>