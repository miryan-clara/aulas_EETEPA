<?php
 include "conexao.php";
 $result = $conn -> query ("SELECT *FROM catalogo");
 ?>

 <div class="catalogo">
    <?php while ($item = $result->fetch_assoc()):?>
        <div class="card">
            <img src="<?= $item ['imagem'] ?>">
            <h2><?= $item ['nome'] ?></h2>
            <p><?= $item ['descricao'] ?></p>
            <span><?= $item ['preco'] ?></span>
        </div>
    <?php endwhile; ?>
</div>