<?php
//require_once __DIR__ . '/../config/config.php';

$host ="192.168.1.139";
$banco = "inventario_miryan";
$usuario = "root";
$senha = "";


try {
    //$pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
   // $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   // $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
//} catch (PDOException $e) {
    // Segurança: Não exibir detalhes do banco para o usuário final em produção
 //   die("Erro técnico: Não foi possível conectar ao motor de dados.");}
$pdo = new PDO(
    "mysql:host=$host;dbname=$banco;charset=utf8",
    $usuario,
    $senha
);
}