<?
//EXERCICIOS CADERNO DOS ALUNOS

//1 ENVIAR DADOS COM METODO POST
if ($_SERVER['request_method']== 'post')//VERIFICA QUAL METODO HTTP foi usado para acessar a página.
{

$nome = $_post['nome'] ?? '';//É a superglobal do PHP que armazena os dados enviados pelo formulário.
$idade = $_post['idade'] ?? '';//É uma forma segura de capturar variáveis, campo nome ou idade não tiver sido enviado no POST 
// (estiver nulo ou não existir), o PHP define a variável como uma string vazia (?? '')

echo "Nome: $nome <br>";
echo "Idade: $idade";
}

else{
    echo "Acesso não permitido";
}
//EXERCICIO 2 PHP
$sql = "SELECT * FROM produtos";
$stmt = $pdo->prepare($sql);
$stmt->execute();

$resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

//EXERCICIO 3 DIFERENÇA EM GET E POST
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
	echo "Acesso não permitido";
	exit;
}

$nome  = $_POST['nome'] ?? '';
$idade = $_POST['idade'] ?? '';

echo "Nome: $nome <br>";
echo "Idade: $idade";


//TRANSFORMAÇÃO DE ALGORITMO

if ($_SERVER['REQUEST_METHOD'] == 'POST')// Verifica se a requisição é do tipo POST
 {

	$nome = $_POST['nome'] ?? '';// Captura o nome ou define como vazio se não existir

	if (!empty($nome))// Verificação se o nome foi informado
     {
    	echo "Bem-vindo(a), $nome!";
	} else {
    	echo "Nome não informado";
	}

} else {
	echo "Envie o formulário corretamente";
}



