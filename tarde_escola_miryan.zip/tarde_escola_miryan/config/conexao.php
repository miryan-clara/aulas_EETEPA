<?php
// arquivo: config/conexao.php
define('DB_HOST', 'localhost');
define('DB_NAME', 'tarde_escola_miryan');
define('DB_USER', 'user_miryan');
define('DB_PASS', '#Pasdedeux456');
define('DB_CHAR', 'utf8mb4');

function getConexao(): PDO {
static $pdo = null;
if ($pdo === null) {
$dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHAR;
$opcoes = [
PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
PDO::ATTR_EMULATE_PREPARES => false,
];
try {
$pdo = new PDO($dsn, DB_USER, DB_PASS, $opcoes);
} catch (PDOException $e) {
error_log($e->getMessage());
die('Falha na conexão. Contate o administrador.');
}
}
return $pdo;
}

?>