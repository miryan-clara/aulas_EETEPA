<?php
require_once "../config/conexao.php";[cite: 1]


$id = $_GET['id'] ?? 0;
$mensagem = "";


// 1. Busca os dados atuais da disciplina
$sql = "SELECT * FROM disciplinas WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $id]);
$disciplina = $stmt->fetch();


if (!$disciplina) {
    die("Disciplina não encontrada.");
}


// 2. Processa o formulário de atualização
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome          = trim($_POST['nome']);
    $carga_horaria = intval($_POST['carga_horaria']);


    if (!empty($nome) && $carga_horaria > 0) {
        try {
            $sql = "UPDATE disciplinas SET nome = :nome, carga_horaria = :carga_horaria WHERE id = :id";[cite: 1]
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':nome'          => $nome,
                ':carga_horaria' => $carga_horaria,
                ':id'            => $id
            ]);


            header("Location: listar.php");
            exit;


        } catch (PDOException $e) {
            $mensagem = "Erro ao atualizar disciplina: " . $e->getMessage();
        }
    } else {
        $mensagem = "Preencha todos os campos corretamente.";
    }
}
?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Disciplina</title>
</head>
<body>
    <h2>Editar Disciplina</h2>


    <?php if (!empty($mensagem)): ?>
        <p style="color: red;"><?= htmlspecialchars($mensagem) ?></p>
    <?php endif; ?>


    <form method="POST">
        <label>Nome:</label><br>
        <input type="text" name="nome" value="<?= htmlspecialchars($disciplina['nome']) ?>" required><br><br>


        <label>Carga Horária (horas):</label><br>
        <input type="number" name="carga_horaria" value="<?= $disciplina['carga_horaria'] ?>" min="1" required><br><br>


        <button type="submit">Atualizar</button>
        <a href="listar.php">Cancelar</a>
    </form>
</body>
</html>
