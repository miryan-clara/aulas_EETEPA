 <!DOCTYPE html>
 <html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <title>Sistema Escolar EETEPA</title>
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
<body>
    <div class="logo">
    <h1>Sistema Escolar EETEPA</h1>
    </div>

    <hr>

    <section class="menu">
    <h3>Menu Principal</h3>

    <div class="lista">
    <ul>
        <li><a href="alunos/listar.php">Gerenciar Alunos</a></li>
        <li><a href="disciplinas/listar.php">Gerenciar Disciplinas</a></li>
        <li><a href="matriculas/listar.php">Gerenciar Matrículas</a></li>
    </ul>
    </div>
    
    </section>
</body>
 </html>