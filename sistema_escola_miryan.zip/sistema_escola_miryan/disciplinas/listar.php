<?php
require_once "../config/conexao.php";[cite:1] 
try {
    //BUSCA TODAS AS DISCIPLINAS ORDENADAS POR NOME
    $sql = "SELECT * FROM disciplinas ORDER BY  nome ASC";
    $stmt = $pdo->query($sql);
    $disciplinas = $stmt->fetchALL();

} catch (PDOException $e){
    die("Erro ao consultar disciplinas: " . $e->getMessage());

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Lista de Disciplinas</title>
    <link rel="stylesheet" href="">

</head>
<body>
    <h2>Displinas Cadastrar</h2>

    <a href="cadastrar.php">+ Cadastrar nova disciplina</a>
    <a href="../index.html">Página Inicial</a>
    <br><br>

    <table border="1" cellpadding="10" cellspacing="0">[cite: 1]
        <thead>
            <tr>
                <th>ID</th>[cite: 1] 
                <th>Nome da disciplina</th>
                <th>Carga horária</th>[cite: 1] 
                <th>Ações</th>[cite: 1] 
            </tr>
        </thead>
        <tbody>
            <?php if(count($disciplinas) > 0): ?>
                <?php foreach ($disciplinas as $d): ?>
                    <tr>
                        <td><?= $d['id'] ?></td>
                        <td><?= htmlspecialchars($d['nome'])?></td>
                        <td><?= $d['carga_horaria'] ?> horas </td>
                        <td>
                            <a href="editar.php?id=<? $d['id'] ?>">Editar</a>
                            <a href="excluir.php?id=<? $d['id'] ?>" onclick="return confirm('Deseja realmente excluir esta disciplina?')">Excluir</a>

                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4">nenhuma disciplina cadastrada.</td>
                        </tr>
                        <?php endif; ?>
    
        </tbody>
    </table>
    
</body>
</html>