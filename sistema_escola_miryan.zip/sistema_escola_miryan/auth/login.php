<?php
// CREATE – Inserir novo aluno
function criarAluno(array $dados): int {
$pdo = getConexao();
$stmt = $pdo->prepare(
'INSERT INTO alunos (nome, matricula, email, dt_nasc)
VALUES (:nome, :matricula, :email, :dt_nasc)'
);
$stmt->execute($dados);
return (int) $pdo->lastInsertId();
}

// READ – Listar com paginação
function listarAlunos(int $pagina=1, int $porPagina=10): array {
$pdo = getConexao();
$offset = ($pagina - 1) * $porPagina;
$stmt = $pdo->prepare(
    'SELECT id, nome, matricula, email
FROM alunos WHERE ativo=1
ORDER BY nome LIMIT :limite OFFSET :offset'
);
$stmt->bindValue(':limite', $porPagina, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
return $stmt->fetchAll();
}

// UPDATE – Atualizar aluno
function atualizarAluno(int $id, array $dados): bool {
$pdo = getConexao();
$stmt = $pdo->prepare(
'UPDATE alunos
SET nome=:nome, email=:email
WHERE id=:id'
);
$dados[':id'] = $id;
return $stmt->execute($dados);
}

// DELETE lógico – Desativar aluno
function desativarAluno(int $id): bool {
$pdo = getConexao();
$stmt = $pdo->prepare('UPDATE alunos SET ativo=0 WHERE id=:id');
return $stmt->execute([':id' => $id]);
}