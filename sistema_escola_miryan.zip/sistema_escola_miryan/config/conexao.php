<?php
$host = "localhost";
$banco = "tarde_escola_miryan";
$usuario = "miryan";
$senha = "Pasdedeux456";

try{

$pdo = new PDO(
    "mysql:host=$host;dgname=$banco;charset=utf8", 
    $usuario,
    $senha
);

$pdo->setAttribute(
    PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION
);

} catch(PDOException $e){
    die("Erro na conexão: ". $e->getMessage());
    
}
?>